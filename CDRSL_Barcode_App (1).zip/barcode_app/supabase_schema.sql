-- ═══════════════════════════════════════════════════════════════════════════
-- CDRSL Barcode & Expiry System — Supabase SQL Schema  (FIXED)
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ═══════════════════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────────────────────────────────
-- STEP 0: Drop all tables cleanly before recreating
-- NOTE: We use "cdrsl_users" instead of "users" to avoid conflict with
-- Supabase's built-in auth.users / public.users table.
-- ─────────────────────────────────────────────────────────────────────────
drop table if exists inward_line_items cascade;
drop table if exists inward_headers     cascade;
drop table if exists barcode_master     cascade;
drop table if exists cdrsl_users        cascade;

-- ─────────────────────────────────────────────────────────────────────────
-- 1. CDRSL USERS
-- ─────────────────────────────────────────────────────────────────────────
create table cdrsl_users (
    id          uuid        primary key default gen_random_uuid(),
    name        text        not null,
    email       text        not null unique,
    role        text        not null default 'Verifier',
    department  text,
    google_id   text,
    is_active   boolean     not null default true,
    created_at  timestamptz not null default now()
);

-- ─────────────────────────────────────────────────────────────────────────
-- 2. BARCODE MASTER
-- ─────────────────────────────────────────────────────────────────────────
create table barcode_master (
    id          uuid        primary key default gen_random_uuid(),
    item_no     text        not null,
    barcode     text        not null unique,
    description text,
    uom         text,
    category    text,
    created_at  timestamptz not null default now()
);

create index idx_barcode_master_barcode on barcode_master(barcode);
create index idx_barcode_master_item_no on barcode_master(item_no);

-- ─────────────────────────────────────────────────────────────────────────
-- 3. INWARD HEADERS
-- ─────────────────────────────────────────────────────────────────────────
create table inward_headers (
    id                  uuid        primary key default gen_random_uuid(),
    document_no         text        not null unique,
    session_datetime    timestamptz not null default now(),
    invoice_no          text,
    boe_no              text,
    boe_date            date,
    inward_date         date,
    goods_receipt_date  date,
    file_no             text,
    container_no        text,
    invoice_lines       integer,
    actual_lines        integer,
    expiry_required     text        not null default 'Yes',
    expiry_threshold    numeric(5,2) not null default 70.00,
    verified_by         text,
    status              text        not null default 'Active',
    created_at          timestamptz not null default now()
);

create index idx_headers_doc_no on inward_headers(document_no);
create index idx_headers_status on inward_headers(status);

-- ─────────────────────────────────────────────────────────────────────────
-- 4. INWARD LINE ITEMS
-- ─────────────────────────────────────────────────────────────────────────
create table inward_line_items (
    id              uuid        primary key default gen_random_uuid(),
    document_no     text        not null references inward_headers(document_no) on delete cascade,
    serial_no       text        not null,
    item_no         text,
    barcode         text,
    description     text,
    remark          text,
    mfg_date        date,
    expiry_date     date,
    shelf_life_pct  numeric(7,2),
    qty             integer     not null default 1,
    expiry_required text,
    inward_date     date,
    verified_by     text,
    created_at      timestamptz not null default now()
);

create index idx_lines_doc_no  on inward_line_items(document_no);
create index idx_lines_barcode on inward_line_items(barcode);
create index idx_lines_item_no on inward_line_items(item_no);

-- ─────────────────────────────────────────────────────────────────────────
-- 5. ROW LEVEL SECURITY
-- ─────────────────────────────────────────────────────────────────────────
alter table cdrsl_users        enable row level security;
alter table barcode_master     enable row level security;
alter table inward_headers     enable row level security;
alter table inward_line_items  enable row level security;

create policy "full_access" on cdrsl_users       for all using (true) with check (true);
create policy "full_access" on barcode_master    for all using (true) with check (true);
create policy "full_access" on inward_headers    for all using (true) with check (true);
create policy "full_access" on inward_line_items for all using (true) with check (true);

-- ─────────────────────────────────────────────────────────────────────────
-- 6. SEED DATA
-- ─────────────────────────────────────────────────────────────────────────
insert into cdrsl_users (name, email, role, department, is_active) values
    ('Sweetson Joseph', 'sweetson@cdrsl.com', 'Admin',      'Warehouse', true),
    ('Ravi Kumar',      'ravi@cdrsl.com',      'Supervisor', 'Inward',    true),
    ('Priya Nair',      'priya@cdrsl.com',     'Verifier',   'Quality',   true)
on conflict (email) do nothing;
